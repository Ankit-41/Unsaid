import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, MessageCircle, Shield, Lock, Users, Sparkles } from "lucide-react";

const HomePage = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const styles = `
    @keyframes float {
      0% { transform: translateY(0px); }
      50% { transform: translateY(-20px); }
      100% { transform: translateY(0px); }
    }

    @keyframes pulse {
      0%, 100% { opacity: 0.6; }
      50% { opacity: 1; }
    }

    @keyframes slideUp {
      from { transform: translateY(20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    .hero-gradient {
      background: radial-gradient(circle at top center, rgba(124, 58, 237, 0.15) 0%, rgba(0, 0, 0, 0) 70%),
                  radial-gradient(circle at bottom left, rgba(99, 102, 241, 0.1) 0%, rgba(0, 0, 0, 0) 70%);
    }

    .card-gradient {
      background: linear-gradient(
        135deg,
        rgba(124, 58, 237, 0.1) 0%,
        rgba(99, 102, 241, 0.1) 100%
      );
    }

    .feature-card {
      backdrop-filter: blur(12px);
      border: 1px solid rgba(124, 58, 237, 0.1);
      transition: all 0.3s ease;
    }

    .feature-card:hover {
      transform: translateY(-5px);
      border-color: rgba(124, 58, 237, 0.3);
      box-shadow: 0 8px 30px rgba(124, 58, 237, 0.1);
    }

    .floating-animation {
      animation: float 6s ease-in-out infinite;
    }

    .pulse-animation {
      animation: pulse 3s ease-in-out infinite;
    }

    .slide-up {
      opacity: 0;
      transform: translateY(20px);
    }

    .slide-up.visible {
      animation: slideUp 0.6s ease-out forwards;
    }

    .glow-effect {
      position: relative;
    }

    .glow-effect::after {
      content: '';
      position: absolute;
      inset: -1px;
      background: linear-gradient(45deg, rgba(124, 58, 237, 0.5), rgba(99, 102, 241, 0.5));
      filter: blur(12px);
      z-index: -1;
      opacity: 0;
      transition: opacity 0.3s ease;
    }

    .glow-effect:hover::after {
      opacity: 1;
    }
  `;

  const features = [
    {
      icon: <MessageCircle className="w-6 h-6 text-violet-400" />,
      title: "Anonymous Sharing",
      description: "Share your thoughts, secrets, and stories without revealing your identity"
    },
    {
      icon: <Shield className="w-6 h-6 text-violet-400" />,
      title: "Safe Space",
      description: "A protected environment for IITR students to express themselves freely"
    },
    {
      icon: <Lock className="w-6 h-6 text-violet-400" />,
      title: "Privacy First",
      description: "Your identity remains confidential with our advanced security measures"
    },
    {
      icon: <Users className="w-6 h-6 text-violet-400" />,
      title: "IITR Community",
      description: "Connect with fellow students and share experiences exclusively"
    }
  ];

  return (
    <>
      <style>{styles}</style>
      <main className="min-h-screen bg-[#0A0A0B] text-white overflow-hidden">
        {/* Hero Section */}
        <section className="hero-gradient min-h-[90vh] flex items-center justify-center px-4 relative">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute inset-0 opacity-30">
              <div className="absolute top-10 left-1/4 w-72 h-72 bg-violet-600 rounded-full filter blur-[120px] pulse-animation" />
              <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-indigo-600 rounded-full filter blur-[120px] pulse-animation" />
            </div>
          </div>

          <div className="max-w-7xl mx-auto relative z-10">
            <div className={`text-center ${isVisible ? 'slide-up visible' : 'slide-up'}`} style={{ animationDelay: '0.2s' }}>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-violet-400 to-indigo-400">
                Where IITR's Secrets <br /> Find Their Voice
              </h1>
              <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto mb-8">
                A safe haven for IIT Roorkee students to share their untold stories, 
                thoughts, and experiences anonymously.
              </p>
              <Button 
                className="glow-effect bg-violet-600 hover:bg-violet-700 text-white px-8 py-6 rounded-full text-lg font-medium transition-all duration-300"
                onClick={() => window.location.href = "/login"}
              >
                Join the Community <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-4 relative">
          <div className="max-w-7xl mx-auto">
            <div className={`text-center mb-16 ${isVisible ? 'slide-up visible' : 'slide-up'}`} style={{ animationDelay: '0.4s' }}>
              <h2 className="text-3xl md:text-4xl font-bold mb-4 inline-flex items-center gap-2">
                <Sparkles className="w-8 h-8 text-violet-400" />
                Why Choose Unsaid?
              </h2>
              <p className="text-gray-400 max-w-2xl mx-auto">
                Experience a unique platform designed exclusively for IIT Roorkee students
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 px-4">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className={`feature-card card-gradient rounded-xl p-6 ${isVisible ? 'slide-up visible' : 'slide-up'}`}
                  style={{ animationDelay: `${0.6 + index * 0.1}s` }}
                >
                  <div className="mb-4 inline-block p-2 rounded-lg bg-violet-600/10">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-violet-300">
                    {feature.title}
                  </h3>
                  <p className="text-gray-400">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className={`${isVisible ? 'slide-up visible' : 'slide-up'}`} style={{ animationDelay: '0.8s' }}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-violet-300">
                Ready to Share Your Story?
              </h2>
              <p className="text-gray-400 mb-8 text-lg">
                Join thousands of IITR students who have found their voice on Unsaid.
                Your story matters.
              </p>
              <Button 
                className="glow-effect bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-6 rounded-full text-lg font-medium transition-all duration-300"
                onClick={() => window.location.href = "/register"}
              >
                Get Started Now <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default HomePage;